// Program Perkenalan Diri dalam Java

public class Perkenalan {

    public static void main(String[] args) {
        // Mendeklarasikan variabel untuk menyimpan data diri
        String nama = "Eko Muchamad Haryono";
        String nim = "0110223079";
        String prodi = "Teknik Informatika";
        int angkatan = 2023;
        int umur = 21;
        String asal = "Kabupaten Bogor";
        String hobi = "Ngoding & Belajar Hal Baru";

        // Mencetak perkenalan diri
        System.out.println("Halo, nama saya " + nama + ".");
        System.out.println("Saya mahasiswa " + prodi + ".");
        System.out.println("Saya angkatan " + angkatan + ".");
        System.out.println("NIM saya " + nim + ".");
        System.out.println("Saya berumur " + umur + " tahun.");
        System.out.println("Saya berasal dari " + asal + ".");
        System.out.println("Hobi saya adalah " + hobi + ".");
    }
}
