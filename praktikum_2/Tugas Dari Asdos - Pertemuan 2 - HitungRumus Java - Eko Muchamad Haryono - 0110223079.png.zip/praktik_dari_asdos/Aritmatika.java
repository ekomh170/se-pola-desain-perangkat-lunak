
public class Aritmatika {

    public static void main(String[] args) {
        int a = 20;
        // Bisa Double Bisa Juga Float
        double b = 6;

        System.out.println("Penjumlahan = " + (a + b));
        System.out.println("Pengurangan = " + (a - b));
        System.out.println("Perkalian = " + (a * b));
        System.out.println("Pembagian = " + (a / b));
    }
}