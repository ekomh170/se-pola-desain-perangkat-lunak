// Local Variable
public class Mahasiswa {
    public static void main(String[] args) {
        int lokal = 10;
        System.out.println(lokal);
    }
}
