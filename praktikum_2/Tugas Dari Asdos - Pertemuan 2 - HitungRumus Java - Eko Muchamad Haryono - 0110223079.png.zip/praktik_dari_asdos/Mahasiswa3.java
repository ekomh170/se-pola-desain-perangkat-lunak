public class Mahasiswa3 {
    public static String names = "Eko Muchamad Haryono";

    public static  void main(String[] args) {
        System.out.println("Nama Mahasiswa itu adalah " + names);
    }
}